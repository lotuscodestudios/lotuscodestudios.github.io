

$(document).ready(function(){
	$('.ham-menu').click(function(){
		$('.menu-items').toggleClass('open');
		// console.log("Function Active");
	});
});